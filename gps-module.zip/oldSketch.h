#include <WiFi.h>
#include <AsyncTCP.h>

#include <AsyncWebServer_ESP32_ENC.h>
#include "NMEA.h"

#define LEN(arr) ((int)(sizeof(arr) / sizeof(arr)[0]))

union {
  char bytes[4];
  float valor;
} velocidadeGPS;

float latitude;
float longitude;

NMEA gps(GPRMC);  // Creates a GPS data connection with sentence type GPRMC

// Connect WiFi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// WebSocket path
const char* webSocketPath = "wss://archocell.obaa.cloud/vehicle/atv-00001/location";

AsyncWebServer server(80);
AsyncWebSocket ws(webSocketPath);

String jsonMessage;  // JSON string to store the location data

void onWebSocketEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len) {
  // Handle WebSocket events if needed
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(9600);  // Serial2 is connected to the custom chip

  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");

  // Define a route for WebSocket
  ws.onEvent(onWebSocketEvent);
  server.addHandler(&ws);

  // Start server
  server.begin();

  Serial.println("Ready to receive data from GPS!");
  Serial.println();
  Serial.println();
}

void loop() {
  while (Serial2.available()) {
    char serialData = Serial2.read();
    Serial.print(serialData);

    if (gps.decode(serialData)) {
      if (gps.gprmc_status() == 'A') {
        velocidadeGPS.valor = gps.gprmc_speed(KMPH);
      } else {
        velocidadeGPS.valor = 0;
      }

      latitude = gps.gprmc_latitude();
      longitude = gps.gprmc_longitude();

      // Add line break
      Serial.println();
      Serial.println();

      // Show Latitude
      Serial.print(" Latitude: ");
      Serial.println(latitude, 8);

      // Show Longitude
      Serial.print("Longitude: ");
      Serial.println(longitude, 8);

      // Show Speed in km/h
      Serial.print("    Speed: ");
      Serial.print(velocidadeGPS.valor);
      Serial.println(" Km/h");

      // Converts Geographic Coordinates to Cartesian Plane
      convertCoordinatesToCartesian(latitude, longitude);

      // Create JSON message
      jsonMessage = "{\"latitude\":" + String(latitude, 8) +
                    ",\"longitude\":" + String(longitude, 8) +
                    ",\"speed\":" + String(velocidadeGPS.valor) + "}";

      // Send JSON message to WebSocket clients
      ws.textAll(jsonMessage.c_str(), jsonMessage.length());
    }
  }

  // Handle WebSocket events
  ws.cleanupClients();
  delay(10);
}

void convertCoordinatesToCartesian(float latitude, float longitude) {
  float latRadius = latitude * (PI) / 180;
  float lonRadius = longitude * (PI) / 180;

  int earthRadius = 6371;

  float posX = earthRadius * cos(latRadius) * cos(lonRadius);
  float posY = earthRadius * cos(latRadius) * sin(lonRadius);

  Serial.println("Cartesian Plane");
  Serial.print("        X: ");
  Serial.println(posX);
  Serial.print("        Y: ");
  Serial.println(posY);
}
